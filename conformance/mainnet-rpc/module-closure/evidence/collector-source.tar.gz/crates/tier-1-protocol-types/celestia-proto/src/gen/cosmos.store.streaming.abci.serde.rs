impl serde::Serialize for ListenCommitRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if true {
            len += 1;
        }
        if true {
            len += 1;
        }
        if true {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("cosmos.store.streaming.abci.ListenCommitRequest", len)?;
        if true {
            #[allow(clippy::needless_borrow)]
            #[allow(clippy::needless_borrows_for_generic_args)]
            struct_ser.serialize_field("block_height", ToString::to_string(&self.block_height).as_str())?;
        }
        if let Some(v) = self.res.as_ref() {
            struct_ser.serialize_field("res", v)?;
        }
        if true {
            struct_ser.serialize_field("change_set", &self.change_set)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ListenCommitRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "block_height",
            "blockHeight",
            "res",
            "change_set",
            "changeSet",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            BlockHeight,
            Res,
            ChangeSet,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "blockHeight" | "block_height" => Ok(GeneratedField::BlockHeight),
                            "res" => Ok(GeneratedField::Res),
                            "changeSet" | "change_set" => Ok(GeneratedField::ChangeSet),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ListenCommitRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct cosmos.store.streaming.abci.ListenCommitRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ListenCommitRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut block_height__ = None;
                let mut res__ = None;
                let mut change_set__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::BlockHeight => {
                            if block_height__.is_some() {
                                return Err(serde::de::Error::duplicate_field("blockHeight"));
                            }
                            block_height__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Res => {
                            if res__.is_some() {
                                return Err(serde::de::Error::duplicate_field("res"));
                            }
                            res__ = map_.next_value()?;
                        }
                        GeneratedField::ChangeSet => {
                            if change_set__.is_some() {
                                return Err(serde::de::Error::duplicate_field("changeSet"));
                            }
                            change_set__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(ListenCommitRequest {
                    block_height: block_height__.unwrap_or_default(),
                    res: res__,
                    change_set: change_set__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("cosmos.store.streaming.abci.ListenCommitRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ListenCommitResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("cosmos.store.streaming.abci.ListenCommitResponse", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ListenCommitResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ListenCommitResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct cosmos.store.streaming.abci.ListenCommitResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ListenCommitResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(ListenCommitResponse {
                })
            }
        }
        deserializer.deserialize_struct("cosmos.store.streaming.abci.ListenCommitResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ListenFinalizeBlockRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if true {
            len += 1;
        }
        if true {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("cosmos.store.streaming.abci.ListenFinalizeBlockRequest", len)?;
        if let Some(v) = self.req.as_ref() {
            struct_ser.serialize_field("req", v)?;
        }
        if let Some(v) = self.res.as_ref() {
            struct_ser.serialize_field("res", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ListenFinalizeBlockRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "req",
            "res",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Req,
            Res,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "req" => Ok(GeneratedField::Req),
                            "res" => Ok(GeneratedField::Res),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ListenFinalizeBlockRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct cosmos.store.streaming.abci.ListenFinalizeBlockRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ListenFinalizeBlockRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut req__ = None;
                let mut res__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Req => {
                            if req__.is_some() {
                                return Err(serde::de::Error::duplicate_field("req"));
                            }
                            req__ = map_.next_value()?;
                        }
                        GeneratedField::Res => {
                            if res__.is_some() {
                                return Err(serde::de::Error::duplicate_field("res"));
                            }
                            res__ = map_.next_value()?;
                        }
                    }
                }
                Ok(ListenFinalizeBlockRequest {
                    req: req__,
                    res: res__,
                })
            }
        }
        deserializer.deserialize_struct("cosmos.store.streaming.abci.ListenFinalizeBlockRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ListenFinalizeBlockResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("cosmos.store.streaming.abci.ListenFinalizeBlockResponse", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ListenFinalizeBlockResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ListenFinalizeBlockResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct cosmos.store.streaming.abci.ListenFinalizeBlockResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ListenFinalizeBlockResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(ListenFinalizeBlockResponse {
                })
            }
        }
        deserializer.deserialize_struct("cosmos.store.streaming.abci.ListenFinalizeBlockResponse", FIELDS, GeneratedVisitor)
    }
}
